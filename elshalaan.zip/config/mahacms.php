<?php
return [
    'superadmins' => [
        'mahmod@gmail.com',
    ],
    'menu' => [
        [
            'title' => 'Other',
            'items' => [
                [
                    'text' => 'Inbox',
                    'link' => '/inbox',
                ],
            ],
        ],
    ],
];