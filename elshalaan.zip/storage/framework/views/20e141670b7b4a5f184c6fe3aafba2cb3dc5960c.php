<?php $__env->startPush('style'); ?>
<link href="/css/portfolio.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!--Start About Us-->
    <section class="title">
        <div class="container">
            <h2 class="right"><?php echo e($portfolio->name); ?></h2>
        </div>
    </section>
    <!--End About Us-->

    <!--Start Section portfolio-->
    <section  class="portfolio">
        <div class="container">
            <div class="row ">
            <?php $__currentLoopData = $portfolio->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-s-12 col-m-6 col-l-4 portfolio-block ">
                    <div class="block">
                        <div class="img-block">
                            <img src="/images/<?php echo e($t->image); ?>">
                        </div>
                        <p><?php echo e($t->description); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--End Section portfolio-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>