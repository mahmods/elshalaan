<?php $__env->startPush('style'); ?>
<link href="/css/services.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <!--Start About Us-->
    <section class="title">
        <div class="container">
            <h2 class="right">خدماتنا  </h2>
        </div>
    </section>
    <!--End About Us-->

    <!--Start Section serviece-->
    <section id="Our-Serviece" class="serviece">
        <div class="container">
            <div class="row">

            </div>
            <div class="row">
            <?php $__currentLoopData = $services->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-s-12 col-m-6 col-l-4">
                    <div class="serviece-block">
                        <span>
                            <i><img src="/images/<?php echo e($t->image); ?>"></i>
                        </span>
                        <h3><?php echo e($t->title); ?></h3>
                        <p><?php echo e($t->description); ?></p>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--End Section serviece-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>