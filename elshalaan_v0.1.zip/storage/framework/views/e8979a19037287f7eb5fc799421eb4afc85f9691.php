<?php $__env->startPush('style'); ?>
<link href="/css/team.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!--Start About Us-->
    <section class="title">
        <div class="container">
            <h2 class="right"><?php echo e($fields[0]->name); ?></h2>
        </div>
    </section>
    <!--End About Us-->

    <!--Start Section Our Team-->
    <section id="ourTeam" class="our-team">
        <div class="container">
            <div class="row">
            <?php $__currentLoopData = $fields[0]->value->posts()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-s-12 col-m-6 col-l-3 team-block ">
                    <div class="img-block">
                        <img src="/images/<?php echo e($t->image); ?>">
                    </div>
                    <div class="p-block">
                        <p><?php echo e($t->title); ?></p>
                        <p><?php echo e($t->description); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--End Section Our Team-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>